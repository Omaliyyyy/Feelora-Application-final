import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get uid => _auth.currentUser?.uid;

  Future<Map<String, dynamic>?> loadUserData() async {
    if (uid == null) {
      debugPrint('[Firestore] loadUserData: uid is null, skipping.');
      return null;
    }
    try {
      debugPrint('[Firestore] loadUserData: fetching doc for $uid');
      final doc = await _db
          .collection('users')
          .doc(uid)
          .get()
          .timeout(const Duration(seconds: 10));
      if (!doc.exists) {
        debugPrint('[Firestore] loadUserData: doc does not exist.');
        return null;
      }
      debugPrint('[Firestore] loadUserData: success.');
      return doc.data() as Map<String, dynamic>;
    } catch (e) {
      debugPrint('[Firestore] loadUserData error: $e');
      return null;
    }
  }

  Future<void> saveMoodEntry(String mood) async {
    if (uid == null) {
      debugPrint('[Firestore] saveMoodEntry: uid is null, skipping.');
      return;
    }
    debugPrint('[Firestore] saveMoodEntry: saving mood "$mood" for $uid');
    try {
      await _db.collection('users').doc(uid).update({
        'moodHistory': FieldValue.arrayUnion([
          {
            'date': DateTime.now().toIso8601String().split('T')[0],
            'mood': mood,
          }
        ])
      }).timeout(const Duration(seconds: 10));
      debugPrint('[Firestore] saveMoodEntry: success.');
    } catch (e) {
      debugPrint('[Firestore] saveMoodEntry error: $e');
      rethrow;
    }
  }

  Future<void> saveUserRegistration(String email) async {
    if (uid == null) {
      debugPrint('[Firestore] saveUserRegistration: uid is null, skipping.');
      return;
    }
    debugPrint('[Firestore] saveUserRegistration: creating doc for $uid');
    await _db.collection('users').doc(uid).set({
      'email': email,
      'createdAt': FieldValue.serverTimestamp(),
      'currentDay': 1,
      'pathway': '',
      'moodHistory': [],
      'tasksCompleted': {},
    }).timeout(const Duration(seconds: 10), onTimeout: () {
      debugPrint('[Firestore] saveUserRegistration: timed out, continuing with local cache.');
    });
  }

  Future<void> saveMoodAndCalculatePathway(String mood, List<bool> answers) async {
    if (uid == null) {
      debugPrint('[Firestore] saveMoodAndCalculatePathway: uid is null, skipping.');
      return;
    }

    int yesCount = answers.where((a) => a == true).length;
    debugPrint('[Firestore] saveMoodAndCalculatePathway: mood="$mood", yesCount=$yesCount');

    String pathway = 'Active Building Phase';
    if ((mood == 'Low' || mood == 'Very Low' || mood == '😔' || mood == '🌧') && yesCount >= 2) {
      pathway = 'Gentle Recovery Phase';
    } else if (yesCount == 3) {
      pathway = 'Gentle Recovery Phase';
    }

    Map<String, dynamic> tasksCompleted = {};
    for (int i = 1; i <= 21; i++) {
      if (pathway == 'Gentle Recovery Phase') {
        tasksCompleted['day$i'] = {
          'Drink 2L water': false,
          '10 min journaling': false,
          '15 min walk': false,
        };
      } else {
        tasksCompleted['day$i'] = {
          'Drink 2L water': false,
          '30 min exercise': false,
          'Read 10 pages': false,
        };
      }
    }

    await _db.collection('users').doc(uid).set({
      'pathway': pathway,
      'currentDay': 1,
      'tasksCompleted': tasksCompleted,
      'moodHistory': FieldValue.arrayUnion([
        {
          'date': DateTime.now().toIso8601String().split('T')[0],
          'mood': mood,
        }
      ])
    }, SetOptions(merge: true));

    debugPrint('[Firestore] saveMoodAndCalculatePathway: success. Pathway=$pathway');
  }

  Future<void> toggleTaskStatus(int currentDisplayedDay, String taskName, bool isCompleted) async {
    if (uid == null) {
      debugPrint('[Firestore] toggleTaskStatus: uid is null, skipping.');
      return;
    }
    debugPrint('[Firestore] toggleTaskStatus: day=$currentDisplayedDay task="$taskName" done=$isCompleted');

    final docRef = _db.collection('users').doc(uid);
    final snapshot = await docRef.get();
    if (!snapshot.exists) {
      debugPrint('[Firestore] toggleTaskStatus: doc does not exist.');
      return;
    }

    Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;
    int currentActiveDay = data['currentDay'] ?? 1;
    Map<String, dynamic> tasksCompleted = data['tasksCompleted'] != null
        ? Map<String, dynamic>.from(data['tasksCompleted'])
        : {};

    if (!tasksCompleted.containsKey('day$currentDisplayedDay')) return;

    Map<String, dynamic> dayTasks =
        Map<String, dynamic>.from(tasksCompleted['day$currentDisplayedDay']);
    dayTasks[taskName] = isCompleted;
    tasksCompleted['day$currentDisplayedDay'] = dayTasks;

    bool allCompleted = dayTasks.values.every((val) => val == true);
    int nextDay = currentActiveDay;
    if (allCompleted && currentDisplayedDay == currentActiveDay && currentActiveDay < 21) {
      nextDay += 1;
      debugPrint('[Firestore] toggleTaskStatus: all tasks done, advancing to day $nextDay');
    }

    await docRef.set({
      'tasksCompleted': tasksCompleted,
      'currentDay': nextDay,
    }, SetOptions(merge: true));

    debugPrint('[Firestore] toggleTaskStatus: success, currentDay=$nextDay');
  }

  Stream<DocumentSnapshot> getUserStream() {
    if (uid == null) return const Stream.empty();
    return _db.collection('users').doc(uid).snapshots();
  }
}
