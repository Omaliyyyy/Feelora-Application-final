import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'screens/splash_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/login_screen.dart';
import 'screens/mood_selection_screen.dart';
import 'screens/questions_screen.dart';
import 'screens/pathway_result_screen.dart';
import 'screens/daily_task_screen.dart';
import 'screens/progress_screen.dart';
import 'screens/profile_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // Enable offline persistence so the app works without internet
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );

  runApp(const FeeloraApp());
}

class FeeloraApp extends StatelessWidget {
  const FeeloraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Feelora',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/onboarding': (context) => const OnboardingScreen(),
        '/login': (context) => const LoginScreen(),
        '/mood': (context) => const MoodSelectionScreen(),
        '/questions': (context) => QuestionsScreen(
              selectedMood: ModalRoute.of(context)!.settings.arguments as String? ?? '',
            ),
        '/pathway': (context) => PathwayResultScreen(),
        '/daily': (context) => DailyTaskScreen(),
        '/progress': (context) => ProgressScreen(),
        '/profile': (context) => ProfileScreen(),
      },
    );
  }

  ThemeData _buildTheme() {
    return ThemeData(
      colorScheme: const ColorScheme.light(
        primary: Color(0xFFC8B6FF),
        secondary: Color(0xFFF8C8DC),
        surface: Color(0xFFB8D8BA),
      ),
      scaffoldBackgroundColor: const Color(0xFFFAF9F6),
      fontFamily: 'Poppins',
      textTheme: const TextTheme(
        displayLarge: TextStyle(
          color: Color(0xFF333333),
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: TextStyle(color: Color(0xFF666666)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFC8B6FF),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
      ),
    );
  }
}
