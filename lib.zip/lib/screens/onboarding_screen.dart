import 'package:flutter/material.dart';
import '../widgets/onboarding_page.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  int _currentPage = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: _controller,
            onPageChanged: (int page) {
              setState(() => _currentPage = page);
            },
            children: const [
              OnboardingPage(
                title: 'How are you feeling lately?',
                description: 'Your emotions are valid. Let’s explore them together.',
              ),
              OnboardingPage(
                title: 'Your emotions matter.',
                description: 'Feelora adapts to your mood intensity to guide you.',
              ),
              OnboardingPage(
                title: 'Start your 21-day reset.',
                description: 'Build gentle habits for emotional well-being.',
              ),
            ],
          ),
          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    3,
                    (index) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentPage == index
                            ? const Color(0xFFC8B6FF)
                            : Colors.grey,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                if (_currentPage == 2)
                  ElevatedButton(
                    onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                    child: const Text('Get Started'),
                  )
                else
                  TextButton(
                    onPressed: () => _controller.nextPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeIn,
                    ),
                    child: const Text(
                      'Next',
                      style: TextStyle(color: Color(0xFFC8B6FF)),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
