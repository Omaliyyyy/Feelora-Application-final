import 'package:flutter/material.dart';
import '../services/firestore_service.dart';

class QuestionsScreen extends StatefulWidget {
  final String selectedMood;
  const QuestionsScreen({super.key, required this.selectedMood});

  @override
  _QuestionsScreenState createState() => _QuestionsScreenState();
}

class _QuestionsScreenState extends State<QuestionsScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  final List<String> questions = const [
    'Have you been sleeping properly?',
    'Are you overthinking frequently?',
    'Do you feel lonely lately?',
  ];

  List<bool> _answers = [];
  bool _isLoading = false;

  Future<void> _submitAnswer(bool answer) async {
    if (_isLoading) return;

    setState(() {
      _answers.add(answer);
    });

    if (_answers.length == questions.length) {
      setState(() => _isLoading = true);

      try {
        await _firestoreService
            .saveMoodAndCalculatePathway(widget.selectedMood, _answers)
            .timeout(
          const Duration(seconds: 10),
          onTimeout: () {
            debugPrint('[QuestionsScreen] Save timed out — Firestore will sync when online.');
          },
        );
      } catch (e) {
        debugPrint('[QuestionsScreen] Error saving pathway: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Could not save your data. Check your connection and try again.'),
              backgroundColor: Colors.redAccent,
            ),
          );
          setState(() => _isLoading = false);
          return;
        }
      }

      if (mounted) {
        setState(() => _isLoading = false);
        Navigator.pushReplacementNamed(context, '/pathway');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    int currentIndex = _answers.length;
    if (currentIndex >= questions.length) currentIndex = questions.length - 1;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.grey),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'A few quick questions',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            const Text(
              'This helps us personalize your pathway.',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 50),
            Text(
              'Question ${currentIndex + 1} of ${questions.length}',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Color(0xFFC8B6FF),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              questions[currentIndex],
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 40),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _submitAnswer(true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFC8B6FF),
                      padding: const EdgeInsets.symmetric(vertical: 20),
                    ),
                    child: const Text('Yes', style: TextStyle(fontSize: 18)),
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _submitAnswer(false),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[300],
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                    ),
                    child: const Text('No', style: TextStyle(fontSize: 18)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
