import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import 'questions_screen.dart';

class MoodSelectionScreen extends StatefulWidget {
  const MoodSelectionScreen({super.key});

  @override
  State<MoodSelectionScreen> createState() => _MoodSelectionScreenState();
}

class _MoodSelectionScreenState extends State<MoodSelectionScreen> {
  final FirestoreService _firestoreService = FirestoreService();

  final List<Map<String, dynamic>> moods = const [
    {'emoji': '😔', 'label': 'Very Low'},
    {'emoji': '🌧', 'label': 'Low'},
    {'emoji': '😐', 'label': 'Neutral'},
    {'emoji': '🌤', 'label': 'Improving'},
    {'emoji': '☀️', 'label': 'Good'},
  ];

  bool _isLoading = false;

  Future<void> _onMoodSelected(String moodLabel) async {
    if (_isLoading) return;
    setState(() => _isLoading = true);

    final userData = await _firestoreService.loadUserData();
    final hasPathway =
        userData != null &&
        userData['pathway'] != null &&
        (userData['pathway'] as String).isNotEmpty;

    if (hasPathway) {
      // Existing user — just save their mood and send to daily tasks
      try {
        await _firestoreService.saveMoodEntry(moodLabel);
      } catch (e) {
        debugPrint('[MoodSelectionScreen] saveMoodEntry error: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Could not save mood. Check your connection.'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
      }
      if (mounted) {
        setState(() => _isLoading = false);
        Navigator.pushReplacementNamed(context, '/daily');
      }
    } else {
      // New user — send to questionnaire
      if (mounted) {
        setState(() => _isLoading = false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => QuestionsScreen(selectedMood: moodLabel),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'How intense is your feeling today?',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 30),
                Expanded(
                  child: ListView.separated(
                    itemCount: moods.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final mood = moods[index];
                      return Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        elevation: 2,
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 10,
                          ),
                          leading: Text(
                            mood['emoji'],
                            style: const TextStyle(fontSize: 32),
                          ),
                          title: Text(
                            mood['label'],
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          trailing: const Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: Colors.grey,
                          ),
                          onTap: () => _onMoodSelected(mood['label']),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          if (_isLoading)
            Container(
              color: Colors.white54,
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }
}
