import 'package:flutter/material.dart';
import 'dart:math';

class DailyTaskScreen extends StatefulWidget {
  const DailyTaskScreen({super.key});

  @override
  State<DailyTaskScreen> createState() => _DailyTaskScreenState();
}

class _DailyTaskScreenState extends State<DailyTaskScreen> {
  final Random _random = Random();

  final List<String> _taskPool = [
    'Drink 8 glasses of water',
    'Meditate for 10 minutes',
    'Go for a 30-minute walk',
    'Read for 20 minutes',
    'Write in your journal',
    'Do 20 push-ups',
    'Eat a healthy breakfast',
    'Call a friend or family member',
    'Stretch for 15 minutes',
    'Avoid social media for 2 hours',
    'Cook a meal at home',
    'Practice deep breathing',
    'Take a cold shower',
    'Clean your workspace',
    'Sleep by 10 PM',
    'Do a 10-minute workout',
    'Write 3 things you\'re grateful for',
    'Spend 30 minutes outdoors',
    'Limit screen time to 2 hours',
    'Try a new healthy recipe',
  ];

  late int currentDay;
  late Map<String, bool> todaysTasks;

  @override
  void initState() {
    super.initState();
    currentDay = _random.nextInt(21) + 1;

    final shuffled = List<String>.from(_taskPool)..shuffle(_random);
    final int taskCount = _random.nextInt(3) + 3; // 3 to 5 tasks
    final selectedTasks = shuffled.take(taskCount).toList();

    todaysTasks = {
      for (var task in selectedTasks) task: false, // all unchecked by default
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 8,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: currentDay / 21,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFC8B6FF),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Day $currentDay of 21',
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            const Text(
              'Today\'s tasks',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 30),
            ...todaysTasks.entries.map((entry) {
              final taskName = entry.key;
              final isDone = entry.value;

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: ListTile(
                  leading: Checkbox(
                    value: isDone,
                    onChanged: (val) {
                      if (val == null) return;

                      final wasAllDone = todaysTasks.values.every((v) => v == true);
                      final willBeAllDone = todaysTasks.entries.every(
                        (e) => e.key == taskName ? val : e.value == true,
                      );

                      setState(() => todaysTasks[taskName] = val);

                      if (val && willBeAllDone && !wasAllDone) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('🎉 Awesome! You completed all tasks for today!'),
                            backgroundColor: Colors.green,
                            duration: Duration(seconds: 4),
                          ),
                        );
                      }
                    },
                    activeColor: const Color(0xFFC8B6FF),
                  ),
                  title: Text(
                    taskName,
                    style: TextStyle(
                      fontSize: 16,
                      decoration: isDone ? TextDecoration.lineThrough : null,
                      color: isDone ? Colors.grey : Colors.black,
                    ),
                  ),
                ),
              );
            }),
            const SizedBox(height: 20),
            Center(
              child: TextButton(
                onPressed: () => Navigator.pushNamed(context, '/progress'),
                child: const Text(
                  'View progress →',
                  style: TextStyle(color: Color(0xFFC8B6FF)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}