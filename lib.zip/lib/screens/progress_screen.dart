import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';

class ProgressScreen extends StatelessWidget {
  ProgressScreen({super.key});
  final FirestoreService _db = FirestoreService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.grey),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline, color: Colors.grey),
            onPressed: () => Navigator.pushNamed(context, '/profile'),
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: _db.getUserStream(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('No document found for this user.'));
          }
          
          var data = snapshot.data!.data() as Map<String, dynamic>?;
          if (data == null) return const Center(child: Text('No data found'));

          int currentDay = data['currentDay'] ?? 1;
          Map<String, dynamic> tasksCompleted = data['tasksCompleted'] ?? {};
          
          String latestMood = "No mood logged";
          List<dynamic> moodHistory = data['moodHistory'] ?? [];
          if (moodHistory.isNotEmpty) {
            latestMood = moodHistory.last['mood'] ?? "No mood logged";
          }

          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Your 21-day journey',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 7,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: 21,
                    itemBuilder: (context, index) {
                      final dayNumber = index + 1;
                      
                      // Check if day is fully completed
                      bool isCompleted = false;
                      if (tasksCompleted.containsKey('day$dayNumber')) {
                        Map<String, dynamic> dayTasks = Map<String, dynamic>.from(tasksCompleted['day$dayNumber']);
                        if (dayTasks.isNotEmpty) {
                          isCompleted = dayTasks.values.every((val) => val == true);
                        }
                      }
                      
                      // Or if it's the active current day and it's not completed
                      bool isActive = dayNumber == currentDay;

                      Color? bgColor = Colors.grey[200];
                      Color textColor = Colors.grey;

                      if (isCompleted) {
                        bgColor = const Color(0xFFC8B6FF);
                        textColor = Colors.white;
                      } else if (isActive) {
                        bgColor = const Color(0xFFC8B6FF).withAlpha(128);
                        textColor = Colors.white;
                      }

                      return Container(
                        decoration: BoxDecoration(
                          color: bgColor,
                          borderRadius: BorderRadius.circular(12),
                          border: isActive && !isCompleted ? Border.all(color: const Color(0xFFC8B6FF), width: 2) : null,
                        ),
                        child: Center(
                          child: Text(
                            '$dayNumber',
                            style: TextStyle(
                              color: textColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.insights, color: Color(0xFFC8B6FF)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Latest Mood',
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              latestMood,
                              style: const TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }
      ),
    );
  }
}
