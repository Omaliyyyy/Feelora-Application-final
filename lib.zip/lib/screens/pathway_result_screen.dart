import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';

class PathwayResultScreen extends StatelessWidget {
  PathwayResultScreen({super.key});
  final FirestoreService _db = FirestoreService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<DocumentSnapshot>(
        stream: _db.getUserStream(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('No document found for this user.'));
          }
          
          var data = snapshot.data!.data() as Map<String, dynamic>?;
          if (data == null) return const Center(child: Text('No data found'));

          String pathway = data['pathway'] ?? 'Your Feeling Pathway';

          return Padding(
            padding: const EdgeInsets.all(30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: const Color(0xFFC8B6FF).withAlpha(51),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.spa, size: 60, color: Color(0xFFC8B6FF)),
                ),
                const SizedBox(height: 30),
                Text(
                  'You are in a\n$pathway',
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Over the next 21 days, you’ll take small, gentle steps to nurture your emotions and build resilience.',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () => Navigator.pushReplacementNamed(context, '/daily'),
                  style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
                  child: const Text('Start Day 1'),
                ),
              ],
            ),
          );
        }
      ),
    );
  }
}
